package com.example.enrollment;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;

import java.text.SimpleDateFormat;
import java.util.Date;
import androidx.appcompat.app.AppCompatActivity;

public class SubjectSelectionActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private int studentId;
    private ListView listView;
    private static final int MAX_CREDITS = 24;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subject_selection);

        studentId = getIntent().getIntExtra("student_id", -1);
        if (studentId == -1) {
            finish();
            return;
        }

        dbHelper = new DatabaseHelper(this);
        listView = findViewById(R.id.listViewSubjects);

        loadSubjects();
    }

    private void loadSubjects() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query("subjects",
                new String[]{"_id", "subject_name", "credits"},
                null, null, null, null, "subject_name ASC");

        String[] from = {"subject_name", "credits"};
        int[] to = {android.R.id.text1, android.R.id.text2};

        SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                this,
                android.R.layout.simple_list_item_2,
                cursor,
                from,
                to,
                0
        );

        listView.setAdapter(adapter);
        listView.setOnItemClickListener((parent, view, position, id) -> {
            cursor.moveToPosition(position);
            int subjectId = cursor.getInt(cursor.getColumnIndexOrThrow("_id"));
            int credits = cursor.getInt(cursor.getColumnIndexOrThrow("credits"));
            enrollSubject(subjectId, credits);
        });
    }

    private void enrollSubject(int subjectId, int credits) {
        // Check if already enrolled
        if (dbHelper.isSubjectEnrolled(studentId, subjectId)) {
            Toast.makeText(this, "You are already enrolled in this subject!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check credit limit
        int currentCredits = dbHelper.getTotalCredits(studentId);
        if (currentCredits + credits > MAX_CREDITS) {
            Toast.makeText(this, "Cannot exceed " + MAX_CREDITS + " credits!", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("student_id", studentId);
        values.put("subject_id", subjectId);
        values.put("enrollment_date", new SimpleDateFormat("yyyy-MM-dd").format(new Date()));

        try {
            long result = db.insertOrThrow("enrollments", null, values);
            if (result != -1) {
                Toast.makeText(this, "Subject enrolled successfully!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed to enroll subject!", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}

