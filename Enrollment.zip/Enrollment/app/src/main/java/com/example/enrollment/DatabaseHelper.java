package com.example.enrollment;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "enrollment.db";
    private static final int DATABASE_VERSION = 1;

    // Tables
    public static final String TABLE_STUDENTS = "students";
    public static final String TABLE_SUBJECTS = "subjects";
    public static final String TABLE_ENROLLMENTS = "enrollments";

    public static final String COLUMN_ID = "_id";

    // Student columns
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_EMAIL = "email";
    public static final String COLUMN_PASSWORD = "password";

    // Subject columns
    public static final String COLUMN_SUBJECT_NAME = "subject_name";
    public static final String COLUMN_CREDITS = "credits";

    // Enrollment columns
    public static final String COLUMN_STUDENT_ID = "student_id";
    public static final String COLUMN_SUBJECT_ID = "subject_id";
    public static final String COLUMN_ENROLLMENT_DATE = "enrollment_date";

    // Create table statements
    private static final String CREATE_TABLE_STUDENTS = "CREATE TABLE " + TABLE_STUDENTS + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_NAME + " TEXT NOT NULL,"
            + COLUMN_EMAIL + " TEXT UNIQUE NOT NULL,"
            + COLUMN_PASSWORD + " TEXT NOT NULL"
            + ")";

    private static final String CREATE_TABLE_SUBJECTS = "CREATE TABLE " + TABLE_SUBJECTS + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_SUBJECT_NAME + " TEXT NOT NULL,"
            + COLUMN_CREDITS + " INTEGER NOT NULL"
            + ")";

    private static final String CREATE_TABLE_ENROLLMENTS = "CREATE TABLE " + TABLE_ENROLLMENTS + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_STUDENT_ID + " INTEGER NOT NULL,"
            + COLUMN_SUBJECT_ID + " INTEGER NOT NULL,"
            + COLUMN_ENROLLMENT_DATE + " TEXT NOT NULL,"
            + "FOREIGN KEY (" + COLUMN_STUDENT_ID + ") REFERENCES " + TABLE_STUDENTS + "(" + COLUMN_ID + ") ON DELETE CASCADE,"
            + "FOREIGN KEY (" + COLUMN_SUBJECT_ID + ") REFERENCES " + TABLE_SUBJECTS + "(" + COLUMN_ID + ") ON DELETE CASCADE,"
            + "UNIQUE(" + COLUMN_STUDENT_ID + ", " + COLUMN_SUBJECT_ID + ")"
            + ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_STUDENTS);
        db.execSQL(CREATE_TABLE_SUBJECTS);
        db.execSQL(CREATE_TABLE_ENROLLMENTS);
        insertDefaultSubjects(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ENROLLMENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SUBJECTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STUDENTS);
        onCreate(db);
    }

    private void insertDefaultSubjects(SQLiteDatabase db) {
        String[][] subjects = {
                {"Math", "3"},
                {"AI", "3"},
                {"Data Structure", "3"},
                {"Numerical", "3"},
                {"Game Development", "3"},
                {"WMP", "3"},
                {"Cyber", "3"},
                {"Calculus", "4"},
                {"Management", "4"},
                {"Last Air Blender", "4"},
                {"Khai Cenat", "4"}
        };

        for (String[] subject : subjects) {
            ContentValues values = new ContentValues();
            values.put(COLUMN_SUBJECT_NAME, subject[0]);
            values.put(COLUMN_CREDITS, subject[1]);
            db.insert(TABLE_SUBJECTS, null, values);
        }
    }

    public long registerStudent(String name, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_PASSWORD, password);
        return db.insert(TABLE_STUDENTS, null, values);
    }

    public boolean checkLogin(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_ID};
        String selection = COLUMN_EMAIL + "=? AND " + COLUMN_PASSWORD + "=?";
        String[] selectionArgs = {email, password};
        Cursor cursor = db.query(TABLE_STUDENTS, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }

    public int getStudentId(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_ID};
        String selection = COLUMN_EMAIL + "=?";
        String[] selectionArgs = {email};
        Cursor cursor = db.query(TABLE_STUDENTS, columns, selection, selectionArgs, null, null, null);
        int studentId = -1;
        if (cursor.moveToFirst()) {
            studentId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID));
        }
        cursor.close();
        return studentId;
    }

    public int getTotalCredits(int studentId) {
        SQLiteDatabase db = this.getReadableDatabase();
        int totalCredits = 0;

        String query = "SELECT SUM(" + COLUMN_CREDITS + ") FROM " + TABLE_SUBJECTS + " s "
                + "INNER JOIN " + TABLE_ENROLLMENTS + " e ON s." + COLUMN_ID + " = e." + COLUMN_SUBJECT_ID
                + " WHERE e." + COLUMN_STUDENT_ID + " = ?";

        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(studentId)});
        if (cursor.moveToFirst()) {
            totalCredits = cursor.getInt(0);
        }
        cursor.close();
        return totalCredits;
    }

    // Check if subject is already enrolled
    public boolean isSubjectEnrolled(int studentId, int subjectId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_ENROLLMENTS
                + " WHERE " + COLUMN_STUDENT_ID + " = ? AND "
                + COLUMN_SUBJECT_ID + " = ?";
        Cursor cursor = db.rawQuery(query,
                new String[]{String.valueOf(studentId), String.valueOf(subjectId)});
        boolean isEnrolled = cursor.getCount() > 0;
        cursor.close();
        return isEnrolled;
    }

    // Enable foreign key constraints
    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }
}

