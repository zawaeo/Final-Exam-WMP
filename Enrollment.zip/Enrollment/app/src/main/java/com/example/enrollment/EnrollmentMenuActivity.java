package com.example.enrollment;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class EnrollmentMenuActivity extends AppCompatActivity {
    private Button btnSelectSubjects, btnViewSummary, btnLogout;
    private int studentId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enrollment_menu);

        studentId = getIntent().getIntExtra("student_id", -1);
        if (studentId == -1) {
            returnToLogin();
            return;
        }

        btnSelectSubjects = findViewById(R.id.btnSelectSubjects);
        btnViewSummary = findViewById(R.id.btnViewSummary);
        btnLogout = findViewById(R.id.btnLogout);

        setupButtons();
    }

    private void setupButtons() {
        btnSelectSubjects.setOnClickListener(v -> {
            Intent intent = new Intent(EnrollmentMenuActivity.this, SubjectSelectionActivity.class);
            intent.putExtra("student_id", studentId);
            startActivity(intent);
        });

        btnViewSummary.setOnClickListener(v -> {
            Intent intent = new Intent(EnrollmentMenuActivity.this, EnrollmentSummaryActivity.class);
            intent.putExtra("student_id", studentId);
            startActivity(intent);
        });

        btnLogout.setOnClickListener(v -> returnToLogin());
    }

    private void returnToLogin() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        // Show logout confirmation dialog
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Do you want to logout?")
                .setPositiveButton("Yes", (dialog, which) -> returnToLogin())
                .setNegativeButton("No", null)
                .show();
    }
}
