package com.example.enrollment;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
public class EnrollmentSummaryActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private int studentId;
    private ListView listView;
    private TextView tvTotalCredits;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enrollment_summary);

        studentId = getIntent().getIntExtra("student_id", -1);
        if (studentId == -1) {
            finish();
            return;
        }

        dbHelper = new DatabaseHelper(this);
        listView = findViewById(R.id.listViewEnrolled);
        tvTotalCredits = findViewById(R.id.tvTotalCredits);

        loadEnrolledSubjects();
    }

    private void loadEnrolledSubjects() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String query = "SELECT s._id, s.subject_name, s.credits, e.enrollment_date " +
                "FROM subjects s " +
                "INNER JOIN enrollments e ON s._id = e.subject_id " +
                "WHERE e.student_id = ?";

        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(studentId)});

        String[] from = {"subject_name", "credits", "enrollment_date"};
        int[] to = {R.id.tvSubjectName, R.id.tvCredits, R.id.tvDate};

        SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                this,
                R.layout.enrolled_subject_item,
                cursor,
                from,
                to,
                0
        );

        listView.setAdapter(adapter);

        int totalCredits = dbHelper.getTotalCredits(studentId);
        tvTotalCredits.setText("Total Credits: " + totalCredits);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
